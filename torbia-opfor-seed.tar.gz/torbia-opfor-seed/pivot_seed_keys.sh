#!/usr/bin/env bash
# ===========================================================================
# pivot_seed_keys.sh  —  Pivot from the foothold (172.24.10.150) using SSH
# KEYS instead of sshpass. Seeds locally, then fans out to the other boxes.
#
# No extra packages needed. Two phases:
#   1) ./pivot_seed_keys.sh setup   -> generates a key (if needed) and copies
#                                      it to each target (type eunwoo.jeong's
#                                      password when prompted, once per host).
#   2) ./pivot_seed_keys.sh          -> key-based fan-out: runs persistence_seed.sh
#                                      locally and on every target (sudo via stdin).
#
# Range / exercise use only.
# ===========================================================================
set -uo pipefail
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

USER_NAME="eunwoo.jeong"
PAYLOAD="persistence_seed.sh"
KEY="$HOME/.ssh/id_ed25519_tot"

TARGETS=(
  172.24.10.180
  172.24.19.66 172.24.19.44 172.24.19.68
  172.24.18.99 172.24.18.135
  172.24.21.12 172.24.21.71 172.24.21.42
  172.24.22.75 172.24.22.19
)

[[ -f "$PAYLOAD" ]] || { echo "ERROR: $PAYLOAD not found next to this script."; exit 1; }

# ---- PHASE 1: key setup --------------------------------------------------
if [[ "${1:-}" == "setup" ]]; then
  if [[ ! -f "$KEY" ]]; then
    echo "Generating key: $KEY"
    ssh-keygen -t ed25519 -N "" -f "$KEY"
  fi
  command -v ssh-copy-id >/dev/null || { echo "ERROR: ssh-copy-id not found."; exit 1; }
  for ip in "${TARGETS[@]}"; do
    echo "--- copying key to ${ip} (enter ${USER_NAME}'s password if prompted) ---"
    ssh-copy-id -i "${KEY}.pub" -o StrictHostKeyChecking=no "${USER_NAME}@${ip}" \
      || echo "  key copy FAILED for ${ip}"
  done
  echo
  echo "Setup done. Now run:  ./pivot_seed_keys.sh"
  exit 0
fi

# ---- PHASE 2: seed -------------------------------------------------------
[[ -f "$KEY" ]] || { echo "No key yet. Run:  ./pivot_seed_keys.sh setup"; exit 1; }

read -rsp "sudo password for ${USER_NAME} (for 'sudo' on each box): " PW; echo
[[ -n "$PW" ]] || { echo "ERROR: no password."; exit 1; }

SSHOPTS=(-i "$KEY" -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
         -o ConnectTimeout=6 -o BatchMode=yes -o LogLevel=ERROR)
TS="$(date +%Y%m%d_%H%M%S)"; LOG="pivot_seed_${TS}.log"

echo "Foothold local + ${#TARGETS[@]} pivot targets."
read -rp "Type SEED to run: " OK
[[ "$OK" == "SEED" ]] || { echo "Aborted."; exit 0; }

{
echo "=== pivot_seed (keys) $(date) as ${USER_NAME} ==="

echo "--- [local] ---"
echo "$PW" | sudo -S -p '' bash "$PAYLOAD" 2>&1 || echo "  LOCAL FAILED"

for ip in "${TARGETS[@]}"; do
  echo "--- [${ip}] ---"
  if ! scp "${SSHOPTS[@]}" "$PAYLOAD" "${USER_NAME}@${ip}:/tmp/.seed.sh" 2>&1; then
    echo "  SCP FAILED (key not installed or unreachable)"; continue
  fi
  ssh "${SSHOPTS[@]}" "${USER_NAME}@${ip}" \
    "echo '$PW' | sudo -S -p '' bash /tmp/.seed.sh; rm -f /tmp/.seed.sh" 2>&1 \
    || echo "  REMOTE RUN FAILED"
done
echo "=== done ==="
} | tee "$LOG"

echo
echo "Log saved: ${LOG}"
