# OPFOR Seeding Kit — "Tears of Torbia"

Plants adversary persistence artifacts across the 12 South Torbia boxes so the
blue team can practice detection and remediation. **Range / exercise use only.**

Files:
- `grant_sudo.sh` — (control node) give `eunwoo.jeong` sudo on all 12 boxes
- `pivot_seed_keys.sh` — (run on .150) key-based pivot that seeds all boxes
- `persistence_seed.sh` — the payload (accounts, shells, sudo) — edit freely
- `deface_index.html` — "Tears of Torbia" defacement page for .150's webroot

---

## STEP 1 — Grant eunwoo.jeong sudo (from the CONTROL NODE)
```bash
chmod +x grant_sudo.sh
./grant_sudo.sh
```
Prompts: Enter (12 saved IPs) -> csra_admin SSH password (blank if key) ->
csra_admin sudo password -> review dry-run -> type **YES**.
Confirms with `id eunwoo.jeong` per host (look for `sudo`/`wheel`).

## STEP 2 — Copy the seed kit to the foothold (.150)
From the control node:
```bash
scp pivot_seed_keys.sh persistence_seed.sh deface_index.html \
    csra_admin@172.24.10.150:/home/eunwoo.jeong/
```

## STEP 3 — On .150: install eunwoo.jeong's key to the other boxes (one-time)
```bash
ssh csra_admin@172.24.10.150      # or log in as eunwoo.jeong
chmod +x pivot_seed_keys.sh persistence_seed.sh
./pivot_seed_keys.sh setup
```
Type `eunwoo.jeong`'s password at each host prompt (~11 times, same session).
Watch for any `key copy FAILED` lines.

## STEP 4 — On .150: seed all boxes
```bash
./pivot_seed_keys.sh
```
Type `eunwoo.jeong`'s sudo password **once** -> type **SEED**.
Seeds .150 locally, then fans out to the other 11 (key auth, no more prompts).
Log saved to `pivot_seed_<timestamp>.log` — check for `SCP FAILED` / `FAILED`.

## STEP 5 — Deface .150's web page
On .150 (path depends on the web server):
```bash
sudo cp deface_index.html /var/www/html/index.html        # Apache / nginx default
# nginx may be /usr/share/nginx/html/index.html
```

---

## Notes
- `persistence_seed.sh` is NOT idempotent — `useradd` errors on a 2nd run for
  existing accounts (harmless, it continues). Run once per box rebuild.
- `echo "tss:tss" | chpasswd` fails if the `tss` account doesn't exist — add a
  `useradd tss` line or ignore the error.
- The payload overwrites `/bin/false` and `/usr/sbin/nologin` — intended and
  detectable; expected on a disposable range.
- Everything here is fictional (Tears of Torbia) — no real org/person impersonated.

## Blue-team artifacts planted (for the answer key)
- `/bin/false` and `/usr/sbin/nologin` replaced with bash
- `mail`, `games` given login shells and added to `sudo`
- New accounts: `vyatta`, `Vyos`, `ird`, `ntp`, `linux`, `golum`, `mode_exporter`
  (note `mode_exporter` typosquats the real `node_exporter`) — all in `sudo`
- Weak passwords on all of the above
- `eunwoo.jeong`'s SSH key in `~/.ssh/authorized_keys` on each box
- Defaced `index.html` on .150
